# Desktop assets: Graphite-Dark (kanagawa) + FairyWren + Bibata

Contenido:
  theme/Graphite-Dark         Tema GTK oscuro con fondo Kanagawa dragon (ya compilado)
  icons/FairyWren             Iconos FairyWren (carpetas en blanco por defecto)
  cursor/Bibata-Modern-Ice    Cursores Bibata Modern Ice
  patches/                    Parches sass para reconstruir el tema desde el fuente
                              (paleta Kanagawa dragon, color claro en sidebars/Thunar,
                              y fix del keybind negro en los menús GTK3 clásicos)

Instalación:
  # 1. Tema GTK
  mkdir -p ~/.local/share/themes
  cp -r theme/Graphite-Dark ~/.local/share/themes/

  # 2. Iconos
  mkdir -p ~/.icons
  cp -r icons/FairyWren ~/.icons/
  gtk-update-icon-cache ~/.icons/FairyWren

  # 3. Cursores (el enlace en ~/.icons es obligatorio para niri)
  mkdir -p ~/.local/share/icons ~/.icons
  cp -r cursor/Bibata-Modern-Ice ~/.local/share/icons/
  ln -sfn ~/.local/share/icons/Bibata-Modern-Ice ~/.icons/Bibata-Modern-Ice

Configuración (settings.ini, .gtkrc-2.0, niri, gsettings):
  Ver README principal del repo para los valores exactos. Resumen:
    gtk-theme-name=Graphite-Dark
    gtk-icon-theme-name=FairyWren
    gtk-cursor-theme-name=Bibata-Modern-Ice
    gtk-application-prefer-dark-theme=1

Reconstruir el tema desde el fuente (opcional):
  git clone https://github.com/vinceliuice/Graphite-gtk-theme
  cd Graphite-gtk-theme
  patch -p1 < /path/patches/graphite-kanagawa-dragon.patch
  ./install.sh -c dark -l        # requiere sassc

Color de carpetas (FairyWren):
  ln -sfn <color> ~/.icons/FairyWren/places/colours/default
  gtk-update-icon-cache ~/.icons/FairyWren
  Colores: white, blue, green, red, etc. (ver con ls ~/.icons/FairyWren/places/colours/)